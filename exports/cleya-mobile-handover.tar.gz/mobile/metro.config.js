const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const projectRoot = __dirname;
const monorepoRoot = path.resolve(projectRoot, '../..');

const config = getDefaultConfig(projectRoot);

config.watchFolders = [monorepoRoot];
config.resolver.nodeModulesPaths = [
  path.resolve(projectRoot, 'node_modules'),
  path.resolve(monorepoRoot, 'node_modules'),
];

config.resolver.blockList = [
  /\.local\/.*/,
  /apps\/frontend\/.*/,
  /apps\/backend\/.*/,
  /\.git\/.*/,
  /\.cache\/.*/,
  /\.canvas\/.*/,
];

module.exports = config;
